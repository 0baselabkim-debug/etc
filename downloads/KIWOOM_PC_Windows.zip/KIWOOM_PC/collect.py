"""Double-click and scheduler entrypoint for the portable package."""
from contextlib import redirect_stdout, redirect_stderr
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from structural_screener.kiwoom_pc import atomic_json, default_date, main, valid_date, Failure


def run():
    args = sys.argv[1:]
    if "--delivery-folder" in args:
        import tkinter as tk
        from tkinter import filedialog, messagebox
        root = tk.Tk()
        root.withdraw()
        folder = filedialog.askdirectory(title="전달용 ZIP을 복사할 비공개 폴더 선택 (취소하면 설정 유지)")
        if folder:
            atomic_json(ROOT / ".kiwoom_local/delivery.json", {"folder": folder})
            messagebox.showinfo("설정 완료", "앞으로 수집 결과 ZIP만 이 폴더에 복사합니다.\n클라우드 수신·DB 적재는 별도 단계입니다.")
        root.destroy()
        return 0
    if "--pick-date" in args:
        import tkinter as tk
        from tkinter import simpledialog, messagebox
        root = tk.Tk()
        root.withdraw()
        day = simpledialog.askstring("키움 수급 수집", "수집할 날짜 8자리 (예: 20261013)\n오늘 자료는 20:30 이후 수집합니다.\n휴장일 자료는 누락으로 표시됩니다.", initialvalue=default_date())
        if day is None:
            root.destroy()
            return 0
        try:
            valid_date(day.strip())
        except Failure:
            messagebox.showerror("날짜 확인", "YYYYMMDD 형식의 실제 날짜를 입력해 주세요.")
            root.destroy()
            return 2
        root.destroy()
        args = ["--date", day.strip()]
    if "--scheduled" in args:
        (ROOT / "output").mkdir(exist_ok=True)
        # No HTTP debug logging or raw exception printing. Retain only this run's safe log.
        with (ROOT / "output/schedule.log").open("w", encoding="utf-8") as log:
            with redirect_stdout(log), redirect_stderr(log):
                return main(["--folder", str(ROOT), *args])
    return main(["--folder", str(ROOT), *args])


if __name__ == "__main__":
    raise SystemExit(run())
