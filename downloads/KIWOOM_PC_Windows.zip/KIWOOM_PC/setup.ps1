﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
try {
    $python = $null
    if (Get-Command py -ErrorAction SilentlyContinue) {
        $candidate = & py -3 -c "import sys; print(sys.executable if sys.version_info >= (3,12) else '')" 2>$null
        if ($LASTEXITCODE -eq 0 -and $candidate) { $python = $candidate.Trim() }
    }
    if (-not $python -and (Get-Command python -ErrorAction SilentlyContinue)) {
        $candidate = & python -c "import sys; print(sys.executable if sys.version_info >= (3,12) else '')" 2>$null
        if ($LASTEXITCODE -eq 0 -and $candidate) { $python = $candidate.Trim() }
    }
    if (-not $python) {
        Write-Host 'Python 3.12 이상이 필요합니다. 공식 설치 안내 페이지를 엽니다.'
        Write-Host 'Windows installer (64-bit)를 설치하고 이 파일을 다시 실행해 주세요.'
        Start-Process 'https://www.python.org/downloads/windows/'
        exit 2
    }
    if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
        & $python -m venv .venv
        if ($LASTEXITCODE -ne 0) { throw 'venv' }
    }
    & '.\.venv\Scripts\python.exe' -m pip install --disable-pip-version-check -r requirements.lock
    if ($LASTEXITCODE -ne 0) { throw 'dependencies' }
    & '.\.venv\Scripts\python.exe' -c "import httpx, dotenv, tkinter; from zoneinfo import ZoneInfo; ZoneInfo('Asia/Seoul')"
    if ($LASTEXITCODE -ne 0) { throw 'runtime' }
    if (-not (Test-Path -LiteralPath '.env')) {
        if (Test-Path -LiteralPath '.env.txt') {
            Copy-Item -LiteralPath '.env.txt' -Destination '.env'
        } else {
            Add-Type -AssemblyName System.Windows.Forms
            $dialog = New-Object System.Windows.Forms.OpenFileDialog
            $dialog.Title = '기존 .env 파일을 선택하세요 (키를 직접 입력할 필요 없음)'
            $dialog.Filter = '환경 파일 (*.env;*.txt)|*.env;*.txt|모든 파일 (*.*)|*.*'
            if ($dialog.ShowDialog() -eq 'OK') {
                Copy-Item -LiteralPath $dialog.FileName -Destination (Join-Path $PSScriptRoot '.env')
            }
        }
    }
    Write-Host '설치 완료. 02_수집실행.cmd를 더블클릭하세요.'
    Write-Host '.env 파일과 이 설치 폴더 전체를 공유하지 마세요. 전달용 ZIP은 보낼파일 폴더에 생성됩니다.'
    exit 0
} catch {
    Write-Host '설치 실패. 인터넷 연결·폴더 쓰기 권한·Python 설치 여부를 확인하고 다시 실행해 주세요.'
    exit 2
}
