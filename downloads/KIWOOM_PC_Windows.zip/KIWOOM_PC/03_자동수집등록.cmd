@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist "%~dp0.venv\Scripts\python.exe" (
  echo 먼저 01_설치.cmd를 실행해 주세요.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0schedule.ps1"
set "collector_exit=%errorlevel%"
pause
exit /b %collector_exit%
