@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0schedule.ps1" -Remove
set "collector_exit=%errorlevel%"
pause
exit /b %collector_exit%
