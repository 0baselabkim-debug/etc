﻿param([switch]$Remove)
$ErrorActionPreference = 'Stop'
try {
    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    $collector = Join-Path $PSScriptRoot 'collect.py'
    $hash = [System.Security.Cryptography.SHA256]::Create()
    $id = [BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($PSScriptRoot))).Replace('-', '').Substring(0, 8)
    $taskName = 'KiwoomPcCollector_' + $id
    if ($Remove) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
        Write-Host '이 폴더의 자동 수집 예약을 해제했습니다.'
        exit 0
    }
    if (-not (Test-Path -LiteralPath $python)) { throw 'install_first' }
    if ((Get-TimeZone).Id -ne 'Korea Standard Time') {
        Write-Host 'Windows 설정 > 시간 및 언어 > 날짜 및 시간에서 표준 시간대를 서울(UTC+09:00)로 설정한 뒤 다시 실행해 주세요.'
        exit 2
    }
    $action = New-ScheduledTaskAction -Execute $python -Argument ('-u "' + $collector + '" --scheduled') -WorkingDirectory $PSScriptRoot
    $trigger = New-ScheduledTaskTrigger -Daily -At '20:30'
    $principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 4) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description '키움 KRX 일별 수급 CSV 수집. PC 켜짐·로그인 필요. 주말 자동 건너뜀.' -Force | Out-Null
    Write-Host '매일 오후 8시 30분 자동 수집을 등록했습니다. 주말에는 조회하지 않습니다.'
    Write-Host 'PC가 켜져 있고 사용자 로그인 상태여야 합니다. 로그: output\schedule.log'
    Write-Host '여러 날 PC를 껐다면 02_수집실행.cmd에서 빠진 날짜를 각각 선택해 주세요.'
    exit 0
} catch {
    Write-Host '예약 설정에 실패했습니다. 작업 스케줄러 접근 권한과 설치 상태를 확인해 주세요.'
    exit 2
}
