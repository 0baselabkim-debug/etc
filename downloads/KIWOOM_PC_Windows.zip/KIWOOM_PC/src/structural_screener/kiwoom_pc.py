"""Read-only Windows/portable Kiwoom collector. No market database or orders.

Official au10001, ka10099, ka10059. Only exported, validated data leaves the PC.
"""
from contextlib import contextmanager
import argparse
import csv
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from email.utils import parsedate_to_datetime
import hashlib
import io
import json
import logging
import os
from pathlib import Path
import re
import shutil
import time
import zipfile
from zoneinfo import ZoneInfo

import httpx
from dotenv import dotenv_values

SEOUL = ZoneInfo("Asia/Seoul")
BASE = "https://api.kiwoom.com"
VERSION = 1
CODE = re.compile(r"[0-9A-Z]{6}\Z")
FIELDS = ("date", "code", "name", "market", "exchange", "foreign_net_million_krw",
          "institution_net_million_krw", "foreign_net_krw", "institution_net_krw",
          "source", "collected_at", "finality")
ERROR_TEXT = {
    "ip_not_registered": "키움 API 사용신청에서 이 PC의 공인 IP를 등록해 주세요. 키 재발급은 필요 없습니다.",
    "ip_changed": "토큰 발급 후 접속 IP가 바뀌었습니다. 같은 네트워크에서 다시 실행해 주세요.",
    "auth_failed": "인증이 거절됐습니다. 키움 앱의 권한·인증 상태를 확인해 주세요.",
    "token_invalid": "토큰이 유효하지 않습니다. 잠시 뒤 다시 실행하면 미완료 종목부터 재개합니다.",
    "missing_credentials": "이 폴더의 .env에 KIWOOM_APP_KEY와 KIWOOM_APP_SECRET이 필요합니다.",
    "already_running": "수집 프로그램이 이미 실행 중입니다. 먼저 실행한 창을 확인해 주세요.",
    "rate_limited": "키움 조회 제한이 계속되어 수집을 중단했습니다. 다른 조회 프로그램을 종료한 뒤 재개해 주세요.",
    "auth_cooldown": "인증을 방금 시도했습니다. 60초 후 다시 실행해 주세요.",
    "network_error": "통신이 실패했습니다. 인터넷 연결을 확인한 뒤 다시 실행해 주세요.",
    "proxy_blocked": "네트워크 프록시가 연결을 거절했습니다.",
    "missing_date": "요청 날짜의 수급이 없습니다. 휴장·미반영·거래정지 여부를 확인해야 합니다.",
}


class Failure(Exception):
    def __init__(self, kind, *, retry=False, fatal=False):
        self.kind, self.retry, self.fatal = kind, retry, fatal
        super().__init__(kind)  # Do not retain provider text, headers, URLs or credentials.


def now():
    return datetime.now(SEOUL).isoformat(timespec="seconds")


def valid_date(value):
    if not isinstance(value, str) or not re.fullmatch(r"\d{8}", value):
        raise Failure("invalid_date")
    try:
        datetime.strptime(value, "%Y%m%d")
    except ValueError:
        raise Failure("invalid_date") from None
    return value


def default_date(at=None):
    at = at or datetime.now(SEOUL)
    # Before the evening run use the last weekday; a weekday is not a verified trading day.
    day = at.date() if (at.hour, at.minute) >= (20, 30) else at.date() - timedelta(days=1)
    while day.weekday() > 4:
        day -= timedelta(days=1)
    return day.strftime("%Y%m%d")


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (ValueError, UnicodeError):
        raise Failure("invalid_local_file") from None


@contextmanager
def single_instance(folder):
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / "collector.lock").open("a+b") as lock:
        lock.seek(0)
        if not lock.read(1):
            lock.write(b"0")
            lock.flush()
        lock.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise Failure("already_running", fatal=True) from None
        try:
            yield
        finally:
            lock.seek(0)
            if os.name == "nt":
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock, fcntl.LOCK_UN)


def credentials(folder):
    # The PC package intentionally reads only the local .env, without interpolating values.
    path = folder / ".env"
    if not path.exists() and (folder / ".env.txt").exists():
        shutil.copyfile(folder / ".env.txt", path)
    data = dotenv_values(path, interpolate=False, encoding="utf-8-sig") if path.exists() else {}
    key, secret = data.get("KIWOOM_APP_KEY"), data.get("KIWOOM_APP_SECRET")
    if not key or not secret:
        raise Failure("missing_credentials", fatal=True)
    return key, secret


def provider_error(data):
    if str(data.get("return_code")) == "0":
        return
    msg = str(data.get("return_msg", ""))
    codes = set(re.findall(r"(?<!\d)(\d{4})(?!\d)", msg))
    codes.add(str(data.get("return_code")))
    if "8050" in codes:
        raise Failure("ip_not_registered", fatal=True)
    if "8010" in codes:
        raise Failure("ip_changed", fatal=True)
    if "8005" in codes:
        raise Failure("token_invalid", fatal=True)
    if codes & {"1700", "1701", "1702"}:
        raise Failure("rate_limited", retry=True, fatal=True)
    if codes & {"8001", "8002", "8003", "8006", "8009", "8030", "8031", "8040"}:
        raise Failure("auth_failed", fatal=True)
    raise Failure("provider_rejected")


class Api:
    def __init__(self, client=None, *, sleep=time.sleep, clock=time.monotonic, interval=1.0):
        for logger in ("httpx", "httpcore"):
            logging.getLogger(logger).disabled = True
        self.client = client or httpx.Client(timeout=30, follow_redirects=False)
        self.sleep, self.clock = sleep, clock
        self.interval = max(1.0, interval)
        self.last = None
        self.token = None
        self.events = []

    def __repr__(self):
        return "Api(<credentials hidden>)"

    def close(self):
        self.token = None
        self.client.close()

    def call(self, api_id, body, *, next_key=""):
        if api_id not in ("au10001", "ka10099", "ka10059"):
            raise Failure("unsupported_api", fatal=True)
        auth = api_id == "au10001"
        if not auth and not self.token:
            raise Failure("token_invalid", fatal=True)
        headers = {"Content-Type": "application/json;charset=UTF-8"}
        if not auth:
            headers.update({"api-id": api_id, "authorization": "Bearer " + self.token,
                            "cont-yn": "Y" if next_key else "N", "next-key": next_key})
        path = "/oauth2/token" if auth else "/api/dostk/stkinfo"
        for attempt in range(1, 2 if auth else 4):
            if self.last is not None:
                self.sleep(max(0, self.interval - (self.clock() - self.last)))
            self.last = self.clock()
            status = None
            delay = 5 * 2 ** (attempt - 1)
            try:
                response = self.client.post(BASE + path, headers=headers, json=body)
                status = response.status_code
                if status == 429:
                    # Honor both numeric and HTTP-date Retry-After. Long waits stop this run.
                    value = response.headers.get("Retry-After", "0")
                    try:
                        wait = float(value)
                    except ValueError:
                        try:
                            wait = (parsedate_to_datetime(value) - datetime.now().astimezone()).total_seconds()
                        except (TypeError, ValueError, OverflowError):
                            wait = 60
                    if wait > 300:
                        raise Failure("rate_limited", fatal=True)
                    delay = max(delay, wait)
                    raise Failure("rate_limited", retry=True, fatal=True)
                if status in (500, 502, 503, 504):
                    raise Failure("server_error", retry=True)
                if status != 200:
                    raise Failure("http_access_denied" if status in (401, 403) else "http_error", fatal=True)
                try:
                    data = response.json()
                except ValueError:
                    raise Failure("invalid_json") from None
                if not isinstance(data, dict):
                    raise Failure("invalid_envelope")
                provider_error(data)
                self.events.append({"api": api_id, "attempt": attempt, "status": status, "outcome": "ok"})
                return data, response.headers
            except httpx.ProxyError:
                error = Failure("proxy_blocked", fatal=True)
            except (httpx.TimeoutException, httpx.NetworkError):
                error = Failure("network_error", retry=True)
            except httpx.HTTPError:
                error = Failure("transport_error", fatal=True)
            except Failure as exc:
                error = exc
            self.events.append({"api": api_id, "attempt": attempt, "status": status, "outcome": error.kind})
            if auth or not error.retry or attempt == 3:
                raise error from None
            self.sleep(delay)

    def authenticate(self, folder):
        key, secret = credentials(folder)
        marker = folder / ".kiwoom_local/auth_attempt.json"
        if marker.exists():
            previous = read_json(marker).get("at", 0)
            if not isinstance(previous, (int, float)) or time.time() - previous < 60:
                raise Failure("auth_cooldown", fatal=True)
        atomic_json(marker, {"at": time.time()})
        data, _ = self.call("au10001", {"grant_type": "client_credentials", "appkey": key, "secretkey": secret})
        if not isinstance(data.get("token"), str) or not data["token"]:
            raise Failure("token_invalid", fatal=True)
        self.token = data["token"]

    def pages(self, api_id, body, field, *, maximum=100):
        key, seen = "", set()
        for _ in range(maximum):
            data, headers = self.call(api_id, body, next_key=key)
            rows = data.get(field)
            if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
                raise Failure("invalid_rows")
            yield rows
            more = headers.get("cont-yn", "N")
            if more not in ("Y", "N", ""):
                raise Failure("invalid_continuation")
            if more != "Y":
                return
            key = headers.get("next-key", "")
            if not key or key in seen:
                raise Failure("pagination_loop")
            seen.add(key)
        raise Failure("page_limit")

    def universe(self):
        stocks, seen = [], set()
        for market_id, market in (("0", "KOSPI"), ("10", "KOSDAQ")):
            count = 0
            for page in self.pages("ka10099", {"mrkt_tp": market_id}, "list"):
                for item in page:
                    code, name = item.get("code"), item.get("name")
                    if not isinstance(code, str) or not CODE.fullmatch(code) or not isinstance(name, str) or not name.strip():
                        raise Failure("invalid_stock")
                    if str(item.get("marketCode")) != market_id:
                        raise Failure("market_mismatch")
                    if code in seen:
                        raise Failure("duplicate_stock")
                    seen.add(code)
                    stocks.append({"code": code, "name": name, "market": market,
                                   "listing_date": str(item.get("regDay", "")),
                                   "security_type": "unverified"})
                    count += 1
            if not count:
                raise Failure("empty_market")
        return sorted(stocks, key=lambda row: (row["market"], row["code"]))

    def flow(self, stock, day):
        body = {"dt": day, "stk_cd": stock["code"], "amt_qty_tp": "1", "trde_tp": "0", "unit_tp": "1"}
        for page in self.pages("ka10059", body, "stk_invsr_orgn"):
            dates = [valid_date(item.get("dt")) for item in page]
            if len(dates) != len(set(dates)):
                raise Failure("duplicate_date")
            matches = [item for item in page if item["dt"] == day]
            if matches:
                return normalized(stock, day, matches[0])
            if dates and max(dates) < day:
                break  # The requested day is absent, never substitute an older date.
        raise Failure("missing_date")


def money(value):
    if not isinstance(value, str) or not re.fullmatch(r"[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?", value.strip()):
        raise Failure("invalid_amount")
    try:
        amount = Decimal(value.strip().replace(",", ""))
        won = amount * 1_000_000
        if won != won.to_integral_value() or abs(won) > 9_000_000_000_000_000_000:
            raise Failure("invalid_amount")
        return format(amount, "f"), str(int(won))
    except InvalidOperation:
        raise Failure("invalid_amount") from None


def safe_cell(value):
    # CSVs can be opened in Excel. Prevent formula interpretation of provider text.
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) or value.startswith(("\t", "\r", "\n")) else value


def normalized(stock, day, data):
    foreign, foreign_won = money(data.get("frgnr_invsr"))
    institution, institution_won = money(data.get("orgn"))
    return dict(zip(FIELDS, (day, stock["code"], safe_cell(stock["name"]), stock["market"], "KRX",
                            foreign, institution, foreign_won, institution_won, "KIWOOM_REST_ka10059", now(),
                            "unverified")))


def validate_row(row, day, stock=None):
    if not isinstance(row, dict) or set(row) != set(FIELDS):
        raise Failure("invalid_row")
    if row["date"] != valid_date(day) or not isinstance(row["code"], str) or not CODE.fullmatch(row["code"]):
        raise Failure("row_identity_mismatch")
    if row["market"] not in ("KOSPI", "KOSDAQ") or row["exchange"] != "KRX" or row["source"] != "KIWOOM_REST_ka10059" or row["finality"] != "unverified":
        raise Failure("invalid_row_metadata")
    if not isinstance(row["name"], str) or not row["name"] or safe_cell(row["name"]) != row["name"]:
        raise Failure("invalid_name")
    try:
        stamp = datetime.fromisoformat(row["collected_at"])
        if stamp.utcoffset() != timedelta(hours=9):
            raise ValueError
    except (ValueError, TypeError):
        raise Failure("invalid_timestamp") from None
    if stock and (row["code"], row["market"], row["name"]) != (stock["code"], stock["market"], safe_cell(stock["name"])):
        raise Failure("row_identity_mismatch")
    for kind in ("foreign", "institution"):
        _, won = money(row[kind + "_net_million_krw"])
        if row[kind + "_net_krw"] != won:
            raise Failure("unit_mismatch")


def csv_bytes(rows, fields):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8-sig")


def write_bundle(folder, day, universe, rows, errors, events, *, outcome, fatal=None, universe_as_of=None):
    members = {
        "flows.csv": csv_bytes(rows, FIELDS),
        "universe.csv": csv_bytes([{**s, "name": safe_cell(s["name"])} for s in universe],
                                   ("code", "name", "market", "listing_date", "security_type")),
        "missing.csv": csv_bytes(errors, ("code", "market", "reason")),
    }
    report = {"schema_version": VERSION, "date": day, "outcome": outcome, "fatal_error": fatal,
              "expected": len(universe), "collected": len(rows), "missing": len(errors),
              "market_counts": {m: {"expected": sum(s["market"] == m for s in universe),
                                     "collected": sum(r["market"] == m for r in rows)} for m in ("KOSPI", "KOSDAQ")},
              "universe_scope": "current_ka10099_markets_0_10", "universe_as_of": universe_as_of,
              "ordinary_stock_filter": "unverified",
              "exchange": "KRX", "session_scope": "provider_daily_scope_not_independently_verified",
              "finality": "unverified", "source_unit": "million_KRW", "normalized_unit": "KRW",
              "created_at": now(), "calls": events}
    members["report.json"] = json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8")
    manifest = {"schema_version": VERSION, "date": day, "sha256": {name: hashlib.sha256(data).hexdigest() for name, data in members.items()}}
    members["manifest.json"] = json.dumps(manifest, indent=2).encode("utf-8")
    destination = folder / "output" / day
    destination.mkdir(parents=True, exist_ok=True)
    for name, data in members.items():
        tmp = destination / (name + ".tmp")
        tmp.write_bytes(data)
        tmp.replace(destination / name)
    bundle = destination / ("kiwoom_" + day + ".zip")
    tmp = bundle.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, data in members.items():
            archive.writestr(name, data)
    tmp.replace(bundle)
    inspect_bundle(bundle)
    outgoing = folder / "보낼파일"
    outgoing.mkdir(exist_ok=True)
    tmp = outgoing / (bundle.name + ".tmp")
    shutil.copyfile(bundle, tmp)
    tmp.replace(outgoing / bundle.name)
    return report


def inspect_bundle(path):
    """Validate a bounded transfer without extraction or database ingestion."""
    names = {"flows.csv", "universe.csv", "missing.csv", "report.json", "manifest.json"}
    try:
        with zipfile.ZipFile(path) as archive:
            items = archive.infolist()
            if len(items) != len(names) or {x.filename for x in items} != names or sum(x.file_size for x in items) > 32_000_000:
                raise Failure("invalid_bundle")
            content = {name: archive.read(name) for name in names}
        manifest = json.loads(content["manifest.json"])
        report = json.loads(content["report.json"])
        if manifest["schema_version"] != VERSION or set(manifest["sha256"]) != names - {"manifest.json"}:
            raise Failure("invalid_manifest")
        for name, expected in manifest["sha256"].items():
            if hashlib.sha256(content[name]).hexdigest() != expected:
                raise Failure("checksum_mismatch")
        day = valid_date(manifest["date"])
        if report["date"] != day or report["schema_version"] != VERSION:
            raise Failure("invalid_manifest")
        def table(name):
            return list(csv.DictReader(io.StringIO(content[name].decode("utf-8-sig"))))
        rows, universe, missing = table("flows.csv"), table("universe.csv"), table("missing.csv")
        stocks = {}
        for s in universe:
            if not CODE.fullmatch(s["code"]) or s["code"] in stocks or s["market"] not in ("KOSPI", "KOSDAQ"):
                raise Failure("invalid_universe")
            stocks[s["code"]] = s
        seen = set()
        for row in rows:
            validate_row(row, day)
            code = row["code"]
            if code in seen or code not in stocks or (row["market"], row["name"]) != (stocks[code]["market"], stocks[code]["name"]):
                raise Failure("invalid_coverage")
            seen.add(code)
        absent = set()
        for item in missing:
            code = item["code"]
            if code in seen or code in absent or code not in stocks or item["market"] != stocks[code]["market"]:
                raise Failure("invalid_coverage")
            absent.add(code)
        if seen | absent != set(stocks) or (report["expected"], report["collected"], report["missing"]) != (len(stocks), len(rows), len(missing)):
            raise Failure("invalid_coverage")
        if report["outcome"] == "complete" and (not rows or missing or {s["market"] for s in universe} != {"KOSPI", "KOSDAQ"}):
            raise Failure("false_completion")
        return report
    except (ValueError, KeyError, TypeError, UnicodeError, zipfile.BadZipFile, RuntimeError):
        raise Failure("invalid_bundle") from None


def collect(folder, day, api, *, progress=print):
    valid_date(day)
    state = folder / ".kiwoom_local" / day
    universe_file = state / "universe.json"
    universe, rows, errors = [], [], []
    snapshot_at = None
    fatal, outcome = None, "failed"
    try:
        if universe_file.exists():
            snapshot = read_json(universe_file)
            universe, snapshot_at = snapshot["stocks"], snapshot["as_of"]
            # Reuse a frozen per-date snapshot, so resume has a stable denominator.
            codes = [s["code"] for s in universe]
            if len(codes) != len(set(codes)) or any(not CODE.fullmatch(c) for c in codes):
                raise Failure("invalid_universe", fatal=True)
        else:
            api.authenticate(folder)
            universe = api.universe()
            snapshot_at = now()
            atomic_json(universe_file, {"as_of": snapshot_at, "stocks": universe})
        pending = []
        for stock in universe:
            path = state / "rows" / (stock["code"] + ".json")
            try:
                row = read_json(path) if path.exists() else None
                if row is not None:
                    validate_row(row, day, stock)
            except Failure:
                row = None  # A damaged checkpoint is re-collected, never silently reused.
            if row is None:
                pending.append(stock)
            else:
                rows.append(row)
        progress(f"대상 {len(universe)}종목 / 재사용 {len(rows)} / 수집 필요 {len(pending)}")
        if pending and not api.token:
            api.authenticate(folder)
        consecutive = 0
        for index, stock in enumerate(pending, 1):
            try:
                row = api.flow(stock, day)
                validate_row(row, day, stock)
                atomic_json(state / "rows" / (stock["code"] + ".json"), row)
                rows.append(row)
                consecutive = 0
            except Failure as exc:
                errors.append({"code": stock["code"], "market": stock["market"], "reason": exc.kind})
                consecutive = consecutive + 1 if exc.kind != "missing_date" else 0
                if exc.fatal or consecutive >= 5:
                    fatal = exc.kind
                    break
            if index % 50 == 0 or index == len(pending):
                progress(f"진행 {index}/{len(pending)} · 저장 {len(rows)} · 누락/오류 {len(errors)}")
    except Failure as exc:
        fatal = exc.kind
    except KeyboardInterrupt:
        fatal = "interrupted"
    saved, failed = {r["code"] for r in rows}, {e["code"] for e in errors}
    errors.extend({"code": s["code"], "market": s["market"], "reason": "not_attempted"}
                  for s in universe if s["code"] not in saved | failed)
    outcome = "complete" if universe and not errors and not fatal else "partial" if rows else "failed"
    return write_bundle(folder, day, universe, sorted(rows, key=lambda r: r["code"]), errors,
                        api.events, outcome=outcome, fatal=fatal, universe_as_of=snapshot_at)


def deliver(folder, day):
    """Explicit user-chosen folder only. No credentials, GitHub or public server."""
    config = folder / ".kiwoom_local/delivery.json"
    if not config.exists():
        return False
    destination = Path(read_json(config)["folder"])
    if not destination.is_dir():
        raise Failure("delivery_folder_unavailable")
    source = folder / "보낼파일" / ("kiwoom_" + day + ".zip")
    inspect_bundle(source)
    target = destination / source.name
    if source.resolve() != target.resolve():
        temp = target.with_suffix(".tmp")
        shutil.copyfile(source, temp)
        temp.replace(target)
    return True


def main(argv=None):
    parser = argparse.ArgumentParser(description="키움 PC 일별 수급 수집 (G0 현장 검증용)")
    parser.add_argument("--folder", type=Path, default=Path.cwd())
    parser.add_argument("--date", default=None)
    parser.add_argument("--inspect", type=Path)
    parser.add_argument("--scheduled", action="store_true")
    args = parser.parse_args(argv)
    api = None
    try:
        if args.inspect:
            report = inspect_bundle(args.inspect)
        else:
            folder = args.folder.resolve()
            day = valid_date(args.date or default_date())
            current = datetime.now(SEOUL)
            if day > current.strftime("%Y%m%d") or (day == current.strftime("%Y%m%d") and (current.hour, current.minute) < (20, 30)):
                raise Failure("before_collection_time")
            if args.scheduled and current.weekday() > 4:
                print("주말: 자동 수집을 건너뜁니다.")
                return 0
            print(f"수집 기준일: {day} / KRX 일별 금액 수급 / 초당 최대 1회")
            with single_instance(folder / ".kiwoom_local"):
                api = Api()
                report = collect(folder, day, api)
                copied = deliver(folder, day)
                print("보낼파일 폴더에 전달용 ZIP을 저장했습니다." + (" 선택한 전달 폴더에도 복사했습니다." if copied else ""))
        print(f"결과: {report['outcome']} / 대상 {report['expected']} / 저장 {report['collected']} / 누락 {report['missing']}")
        if report.get("fatal_error"):
            reason = report["fatal_error"]
            print(ERROR_TEXT.get(reason, "중단 사유: " + reason))
        print("complete는 반환된 두 시장 목록의 수집 완료이며 보통주 전수·확정 수급 검증 완료를 뜻하지 않습니다.")
        return 0 if report["outcome"] == "complete" else 2
    except Failure as exc:
        print(ERROR_TEXT.get(exc.kind, "확인 필요: " + exc.kind))
        return 2
    except (OSError, ValueError, KeyError, TypeError):
        print("파일·설정 처리에 실패했습니다. 폴더 권한과 설치 상태를 확인해 주세요. 인증정보는 공유하지 마세요.")
        return 2
    finally:
        if api:
            api.close()


if __name__ == "__main__":
    raise SystemExit(main())
