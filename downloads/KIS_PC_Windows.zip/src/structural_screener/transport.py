"""HTTPS only; never serialize request URLs, headers, bodies, or exception text."""
from dataclasses import dataclass
import logging
import time
from urllib.parse import urlsplit

import httpx


class SafeFailure(Exception):
    def __init__(self, kind: str, status: int | None = None, attempts: int = 1):
        self.kind, self.status, self.attempts = kind, status, attempts
        super().__init__(kind)


@dataclass
class Event:
    provider: str
    operation: str
    attempt: int
    http_status: int | None
    outcome: str


ALLOWED_HOSTS = {
    "openapi.krx.co.kr", "data-dbg.krx.co.kr", "opendart.fss.or.kr",
    "apiportal.koreainvestment.com", "openapi.koreainvestment.com",
    "fred.stlouisfed.org", "api.stlouisfed.org", "ecos.bok.or.kr",
    "raw.githubusercontent.com",
}


def quiet_http_logs():
    # httpx INFO includes URLs, which may embed ECOS/FRED/DART keys.
    for name in ("httpx", "httpcore"):
        logging.getLogger(name).disabled = True


class Transport:
    def __init__(self, client=None, *, sleep=time.sleep, clock=time.monotonic,
                 interval=1.0, max_attempts=3):
        quiet_http_logs()
        self.client = client or httpx.Client(timeout=20, follow_redirects=False)
        self.sleep, self.clock = sleep, clock
        self.interval, self.max_attempts = interval, max_attempts
        self.events: list[Event] = []
        self.last_request = None

    def close(self):
        self.client.close()

    def _event(self, provider, operation, attempt, status, outcome):
        self.events.append(Event(provider, operation, attempt, status, outcome))

    def request(self, provider, operation, method, url, **kwargs):
        parsed = urlsplit(url)
        if parsed.scheme != "https" or parsed.hostname not in ALLOWED_HOSTS:
            raise SafeFailure("unapproved_destination")
        if parsed.username or parsed.password:
            raise SafeFailure("url_credentials_forbidden")
        for attempt in range(1, self.max_attempts + 1):
            if self.last_request is not None:
                remaining = self.interval - (self.clock() - self.last_request)
                if remaining > 0:
                    self.sleep(remaining)
            self.last_request = self.clock()
            retry_delay = min(8, 2 ** (attempt - 1))
            try:
                response = self.client.request(method, url, **kwargs)
            except httpx.ProxyError:
                self._event(provider, operation, attempt, None, "proxy_blocked")
                raise SafeFailure("proxy_blocked", attempts=attempt) from None
            except (httpx.TimeoutException, httpx.NetworkError):
                self._event(provider, operation, attempt, None, "network_error")
                if attempt == self.max_attempts:
                    raise SafeFailure("network_error", attempts=attempt) from None
            except httpx.HTTPError:
                self._event(provider, operation, attempt, None, "transport_error")
                raise SafeFailure("transport_error", attempts=attempt) from None
            else:
                status = response.status_code
                if 200 <= status < 300:
                    self._event(provider, operation, attempt, status, "received")
                    return response
                if status in (429, 500, 502, 503, 504):
                    self._event(provider, operation, attempt, status, "retryable_http_error")
                    # Respect bounded numeric Retry-After; never log the header.
                    try:
                        retry_delay = min(60, max(retry_delay, float(response.headers.get("Retry-After", "0"))))
                    except ValueError:
                        pass
                    if attempt == self.max_attempts:
                        kind = "rate_limited" if status == 429 else "server_error"
                        if (status == 503 and "text/plain" in response.headers.get("content-type", "")
                                and response.text.startswith("upstream connect error or disconnect/reset before headers.")
                                and "connection timeout" in response.text):
                            kind = "upstream_connect_timeout"
                        raise SafeFailure(kind, status, attempt)
                else:
                    kind = "http_access_denied" if status in (401, 403) else "http_error"
                    self._event(provider, operation, attempt, status, kind)
                    raise SafeFailure(kind, status, attempt)
            self.sleep(retry_delay)

    def json(self, provider, operation, method, url, **kwargs):
        response = self.request(provider, operation, method, url, **kwargs)
        try:
            value = response.json()
        except ValueError:
            raise SafeFailure("invalid_json", response.status_code) from None
        if not isinstance(value, dict):
            raise SafeFailure("invalid_envelope", response.status_code)
        return value

