"""Read-only KIS adapter. Paths/fields verified against the provider's official GitHub."""
from datetime import datetime
from decimal import Decimal, InvalidOperation
import re

from .settings import Settings
from .transport import SafeFailure, Transport

BASE = "https://openapi.koreainvestment.com:9443"
QUOTATIONS = "/uapi/domestic-stock/v1/quotations/"
FLOW_FIELDS = ("stck_bsop_date", "frgn_ntby_tr_pbmn", "orgn_ntby_tr_pbmn")
PRICE_FIELDS = ("stck_bsop_date", "stck_clpr", "stck_oprc", "stck_hgpr", "stck_lwpr", "acml_vol", "acml_tr_pbmn")


def validate_rows(rows, fields):
    if not isinstance(rows, list) or not rows:
        raise SafeFailure("empty_data")
    dates = []
    for row in rows:
        if not isinstance(row, dict) or any(row.get(f) in (None, "") for f in fields):
            raise SafeFailure("missing_fields")
        date = row["stck_bsop_date"]
        try:
            if not isinstance(date, str) or not re.fullmatch(r"\d{8}", date):
                raise ValueError
            datetime.strptime(date, "%Y%m%d")
            for field in fields:
                if field != "stck_bsop_date" and not Decimal(str(row[field])).is_finite():
                    raise ValueError
        except (ValueError, InvalidOperation, TypeError):
            raise SafeFailure("invalid_fields") from None
        dates.append(date)
    if len(set(dates)) != len(dates):
        raise SafeFailure("duplicate_dates")
    return {"rows": len(rows), "earliest_date": min(dates), "latest_date": max(dates)}


class KIS:
    def __init__(self, transport: Transport, settings: Settings):
        self.transport, self.settings = transport, settings
        self._token = None
        self._last_auth_attempt = None

    def __repr__(self):
        return "KIS(<credentials hidden>)"

    def authenticate(self):
        if not all(self.settings.keys.get(k) for k in ("KIS_APP_KEY", "KIS_APP_SECRET")):
            raise SafeFailure("missing_credentials")
        now = self.transport.clock()
        if self._last_auth_attempt is not None and now - self._last_auth_attempt < 60:
            raise SafeFailure("token_cooldown")
        self._last_auth_attempt = now
        # The official guide limits token issuance to once per minute. Do not
        # inherit generic 503 retries from the shared data-request transport.
        auth_transport = Transport(self.transport.client, sleep=self.transport.sleep,
            clock=self.transport.clock, interval=self.transport.interval, max_attempts=1)
        auth_transport.last_request = self.transport.last_request
        try:
            value = auth_transport.json("KIS", "authenticate", "POST", BASE + "/oauth2/tokenP", headers={
                "Content-Type": "application/json", "Accept": "text/plain", "charset": "UTF-8",
                "User-Agent": "Mozilla/5.0",
            }, json={
                "grant_type": "client_credentials", "appkey": self.settings.keys["KIS_APP_KEY"],
                "appsecret": self.settings.keys["KIS_APP_SECRET"],
            })
        finally:
            self.transport.events.extend(auth_transport.events)
            self.transport.last_request = auth_transport.last_request
        # Never print or persist tokens or provider error messages.
        if not isinstance(value.get("access_token"), str) or not value["access_token"]:
            raise SafeFailure("authentication_rejected")
        self._token = value["access_token"]

    def _get(self, operation, tr_id, params):
        if self._token is None:
            self.authenticate()
        value = self.transport.json("KIS", operation, "GET", BASE + QUOTATIONS + operation, params=params, headers={
            "authorization": "Bearer " + self._token,
            "appkey": self.settings.keys["KIS_APP_KEY"], "appsecret": self.settings.keys["KIS_APP_SECRET"],
            "tr_id": tr_id, "custtype": "P",
        })
        if value.get("rt_cd") != "0":
            if value.get("msg_cd") == "EGW00201":
                raise SafeFailure("provider_rate_limited")
            raise SafeFailure("provider_rejected")
        return value

    @staticmethod
    def _params(code, scope):
        if not re.fullmatch(r"\d{6}", code) or scope not in ("J", "NX", "UN"):
            raise SafeFailure("invalid_request")
        return {"FID_COND_MRKT_DIV_CODE": scope, "FID_INPUT_ISCD": code}

    def investors(self, code, scope="J"):
        return self._get("inquire-investor", "FHKST01010900", self._params(code, scope)).get("output")

    def prices(self, code, start, end, scope="J", adjusted=False):
        params = self._params(code, scope)
        params.update(FID_INPUT_DATE_1=start, FID_INPUT_DATE_2=end,
                      FID_PERIOD_DIV_CODE="D", FID_ORG_ADJ_PRC="0" if adjusted else "1")
        return self._get("inquire-daily-itemchartprice", "FHKST03010100", params).get("output2")
