from dataclasses import dataclass, field
from pathlib import Path
import os
from zoneinfo import ZoneInfo

from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[2]
SEOUL = ZoneInfo("Asia/Seoul")
KEY_NAMES = ("KRX_API_KEY", "DART_API_KEY", "KIS_APP_KEY", "KIS_APP_SECRET", "FRED_API_KEY", "ECOS_API_KEY")


@dataclass(repr=False)
class Settings:
    keys: dict[str, str] = field(repr=False)

    def __repr__(self):
        return "Settings(<credentials hidden>)"

    @classmethod
    def load(cls, path: Path = ROOT / ".env"):
        # OS bindings take precedence. Do not mutate or dump the environment.
        local = dotenv_values(path, interpolate=False) if path.exists() else {}
        return cls({name: os.environ.get(name, local.get(name) or "") for name in KEY_NAMES})

    def presence(self):
        return {name: bool(self.keys.get(name)) for name in KEY_NAMES}

