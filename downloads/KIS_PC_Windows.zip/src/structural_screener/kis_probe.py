"""G0-only portable KIS flow probe and credential-free transfer envelope."""
import argparse
import csv
from datetime import datetime, timedelta
from decimal import Decimal
import hashlib
from io import StringIO
import json
import os
from pathlib import Path
import re
import zipfile

from .kis import KIS, FLOW_FIELDS, validate_rows
from .settings import SEOUL, Settings
from .transport import SafeFailure, Transport

FIELDS = ("provider", "stock_code", "market_scope", "observed_date", "collected_at",
          "foreign_net_buy_value_raw", "institution_net_buy_value_raw", "unit_status", "netting_check")
SCOPES = {"J": "KRX", "NX": "NXT", "UN": "COMBINED"}


def records_from_rows(rows, code, scope, collected_at):
    validate_rows(rows, FLOW_FIELDS)
    if not re.fullmatch(r"\d{6}", code) or scope not in SCOPES:
        raise SafeFailure("invalid_request")
    records = []
    for row in rows:
        netting = "unavailable"
        complete = True
        for prefix in ("frgn", "orgn"):
            buy, sell = row.get(prefix + "_shnu_tr_pbmn"), row.get(prefix + "_seln_tr_pbmn")
            if buy in (None, "") or sell in (None, ""):
                complete = False
                continue
            try:
                difference = Decimal(str(buy)) - Decimal(str(sell))
                if not difference.is_finite() or difference != Decimal(str(row[prefix + "_ntby_tr_pbmn"])):
                    raise SafeFailure("inconsistent_net_buy_amount")
            except (ValueError, ArithmeticError):
                raise SafeFailure("invalid_buy_sell_amount") from None
        if complete:
            netting = "passed"
        records.append({"provider": "KIS", "stock_code": code, "market_scope": SCOPES[scope],
            "observed_date": datetime.strptime(row["stck_bsop_date"], "%Y%m%d").date().isoformat(),
            "collected_at": collected_at,
            "foreign_net_buy_value_raw": str(Decimal(str(row["frgn_ntby_tr_pbmn"]))),
            "institution_net_buy_value_raw": str(Decimal(str(row["orgn_ntby_tr_pbmn"]))),
            "unit_status": "unverified", "netting_check": netting})
    return records


def safe_check(operation, function):
    start = datetime.now(SEOUL).isoformat()
    try:
        value = {"operation": operation, "status": "passed", **function()}
    except SafeFailure as exc:
        value = {"operation": operation, "status": "blocked", "reason": exc.kind, "http_status": exc.status}
    value.update(requested_at=start, completed_at=datetime.now(SEOUL).isoformat())
    return value


def collect(settings, transport, *, codes=("005930", "247540"), scope="J", auth_guard=None):
    # Fixed, small diagnostic sample. This is not a full-universe data engine.
    if len(codes) > 10 or len(set(codes)) != len(codes) or any(not re.fullmatch(r"\d{6}", c) for c in codes) or scope not in SCOPES:
        raise SafeFailure("invalid_sample_selection")
    report = {"schema_version": "kis-g0-v1", "stage": "G0", "collected_at": datetime.now(SEOUL).isoformat(),
              "proxy_presence": {n: bool(os.environ.get(n)) for n in ("HTTPS_PROXY", "HTTP_PROXY")},
              "checks": [], "scope": SCOPES[scope], "sample_codes": list(codes),
              "amount_unit_status": "unverified", "full_universe_verified": False}
    def route():
        response = transport.request("KIS", "public_api_route", "GET", "https://openapi.koreainvestment.com:9443/")
        return {"http_status": response.status_code}
    report["checks"].append(safe_check("KIS.public_api_route", route))
    kis = KIS(transport, settings)
    def authenticate():
        if auth_guard:
            auth_guard()
        kis.authenticate()
        return {"token_received": True}
    auth = safe_check("KIS.authenticate", authenticate)
    report["checks"].append(auth)
    records = []
    if auth["status"] == "passed":
        for code in codes:
            def flow(code=code):
                rows = kis.investors(code, scope)
                captured = records_from_rows(rows, code, scope, datetime.now(SEOUL).isoformat())
                records.extend(captured)
                return {"stock_code": code, "rows": len(captured), "amount_fields_present": True,
                        "earliest_date": min(r["observed_date"] for r in captured),
                        "latest_date": max(r["observed_date"] for r in captured)}
            report["checks"].append(safe_check("KIS.investors." + code, flow))
    succeeded = sum(c["status"] == "passed" for c in report["checks"] if c["operation"].startswith("KIS.investors."))
    report.update(outcome="sample_collected" if succeeded == len(codes) else "partial" if records else "blocked",
                  successful_codes=succeeded, record_count=len(records))
    return report, records


def token_guard(folder):
    """Cross-process cooldown on PC; this file contains timestamps only."""
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "token_attempt.json"
    now = datetime.now(SEOUL)
    if path.exists():
        try:
            before = datetime.fromisoformat(json.loads(path.read_text())["attempted_at"])
            if before.tzinfo is None or (now - before).total_seconds() < 60:
                raise SafeFailure("token_cooldown")
        except (ValueError, KeyError, TypeError):
            raise SafeFailure("invalid_token_guard") from None
    path.write_text(json.dumps({"attempted_at": now.isoformat()}))


def export_bundle(report, records, destination, secrets=()):
    csv_text = StringIO(newline="")
    writer = csv.DictWriter(csv_text, fieldnames=FIELDS, quoting=csv.QUOTE_ALL)
    writer.writeheader()
    writer.writerows(records)
    payloads = {"report.json": json.dumps(report, ensure_ascii=False, indent=2).encode(),
                "flows.csv": csv_text.getvalue().encode("utf-8-sig")}
    if any(secret and secret.encode() in payload for payload in payloads.values() for secret in secrets):
        raise SafeFailure("credential_detected_in_export")
    manifest = {"schema_version": "kis-g0-v1", "record_count": len(records),
                "sha256": {name: hashlib.sha256(content).hexdigest() for name, content in payloads.items()}}
    payloads["manifest.json"] = json.dumps(manifest, indent=2).encode()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_suffix(".tmp")
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in payloads.items():
            archive.writestr(name, content)
    temp.replace(destination)


def inspect_bundle(path):
    try:
        with zipfile.ZipFile(path) as archive:
            if set(archive.namelist()) != {"manifest.json", "report.json", "flows.csv"} or len(archive.namelist()) != 3:
                raise SafeFailure("unexpected_bundle_files")
            if any(info.file_size > 10_000_000 for info in archive.infolist()):
                raise SafeFailure("bundle_too_large")
            content = {name: archive.read(name) for name in archive.namelist()}
        manifest = json.loads(content["manifest.json"])
        report = json.loads(content["report.json"])
        if manifest.get("schema_version") != "kis-g0-v1" or report.get("schema_version") != "kis-g0-v1":
            raise SafeFailure("unsupported_bundle_schema")
        for name in ("report.json", "flows.csv"):
            if manifest.get("sha256", {}).get(name) != hashlib.sha256(content[name]).hexdigest():
                raise SafeFailure("bundle_checksum_mismatch")
        reader = csv.DictReader(StringIO(content["flows.csv"].decode("utf-8-sig")))
        if tuple(reader.fieldnames or ()) != FIELDS:
            raise SafeFailure("unexpected_flow_columns")
        rows = list(reader)
        seen = set()
        for row in rows:
            if row["provider"] != "KIS" or not re.fullmatch(r"\d{6}", row["stock_code"]) or row["market_scope"] not in SCOPES.values():
                raise SafeFailure("invalid_import_identity")
            if row["unit_status"] != "unverified" or row["netting_check"] not in ("passed", "unavailable"):
                raise SafeFailure("invalid_import_units")
            datetime.strptime(row["observed_date"], "%Y-%m-%d")
            if datetime.fromisoformat(row["collected_at"]).tzinfo is None:
                raise SafeFailure("missing_import_timezone")
            for field in ("foreign_net_buy_value_raw", "institution_net_buy_value_raw"):
                if not Decimal(row[field]).is_finite():
                    raise SafeFailure("invalid_import_amount")
            identity = (row["stock_code"], row["market_scope"], row["observed_date"])
            if identity in seen:
                raise SafeFailure("duplicate_import_row")
            seen.add(identity)
        if len(rows) != manifest.get("record_count") or len(rows) != report.get("record_count"):
            raise SafeFailure("bundle_count_mismatch")
    except (zipfile.BadZipFile, ValueError, ArithmeticError, KeyError, TypeError, UnicodeError):
        raise SafeFailure("invalid_import_bundle") from None
    # Hashes validate transport integrity, not source authenticity. No production DB writes at G0.
    return {"status": "validated", "record_count": len(rows), "stock_codes": sorted({r["stock_code"] for r in rows}),
            "unit_status": "unverified", "live_origin_independently_verified": False,
            "database_imported": False, "stage": "G0"}


def main():
    parser = argparse.ArgumentParser(description="KIS 전용 G0 금액 수급 검증·안전한 파일 전달")
    parser.add_argument("--inspect", type=Path)
    parser.add_argument("--scope", choices=SCOPES, default="J")
    parser.add_argument("--codes", nargs="+", default=["005930", "247540"])
    parser.add_argument("--folder", type=Path, default=Path.cwd())
    args = parser.parse_args()
    try:
        if args.inspect:
            print(json.dumps(inspect_bundle(args.inspect), ensure_ascii=False, indent=2))
            return 0
        settings = Settings.load(args.folder / ".env")
        transport = Transport(interval=1.0, max_attempts=1)
        try:
            report, records = collect(settings, transport, codes=args.codes, scope=args.scope,
                                      auth_guard=lambda: token_guard(args.folder / ".kis_local"))
        finally:
            transport.close()
        destination = args.folder / "output/kis_probe_result.zip"
        export_bundle(report, records, destination, settings.keys.values())
        print(json.dumps({"outcome": report["outcome"], "record_count": len(records),
                          "successful_codes": report["successful_codes"], "output_file": str(destination),
                          "failure_reasons": [c.get("reason") for c in report["checks"] if c["status"] == "blocked"]}, ensure_ascii=False, indent=2))
        return 0 if report["outcome"] == "sample_collected" else 2
    except (SafeFailure, OSError) as exc:
        print(json.dumps({"status": "blocked", "reason": exc.kind if isinstance(exc, SafeFailure) else "local_file_error"}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
