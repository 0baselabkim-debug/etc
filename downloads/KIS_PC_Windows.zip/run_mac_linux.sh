#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  echo '기존 .env 파일을 이 폴더에 복사하세요. 업로드하지 마세요.'
  exit 2
fi
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python collect.py
