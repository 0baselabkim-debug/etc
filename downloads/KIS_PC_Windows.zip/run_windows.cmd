@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo KIS 수급 연결 검증 도구
echo.
if not exist ".env" (
  if exist ".env.txt" copy /y ".env.txt" ".env" >nul
)
if not exist ".env" (
  echo 기존 .env 파일을 이 폴더에 복사한 뒤 다시 실행해 주세요.
  echo .env 내용이나 인증키는 채팅에 보내지 마세요.
  pause
  exit /b 2
)
if not exist ".venv\Scripts\python.exe" (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,12) else 2)" >nul 2>nul
  if errorlevel 1 (
    echo Python 3.12 이상이 필요합니다. 아래 공식 페이지에서 설치한 뒤 다시 실행해 주세요.
    echo https://www.python.org/downloads/windows/
    pause
    exit /b 2
  )
  py -3 -m venv .venv
  if errorlevel 1 (
    echo 실행 환경을 만들지 못했습니다. 오류 화면만 확인해 주세요. 인증키는 공유하지 마세요.
    pause
    exit /b 2
  )
)
echo 필요한 패키지를 설치하거나 확인합니다. 처음 실행할 때는 인터넷 연결이 필요합니다.
.venv\Scripts\python.exe -m pip install -r requirements.lock
if errorlevel 1 (
  echo 패키지 설치에 실패했습니다. 인터넷 연결을 확인한 뒤 다시 실행해 주세요.
  pause
  exit /b 2
)
.venv\Scripts\python.exe collect.py
set "probe_exit=%errorlevel%"
echo.
if exist "output\kis_probe_result.zip" (
  echo 진단 결과가 만들어졌습니다. 접속 실패 결과도 이 파일에 기록됩니다.
  echo output 폴더의 kis_probe_result.zip만 채팅에 첨부해 주세요.
) else (
  echo 결과 파일을 만들지 못했습니다. 위 안내를 확인해 주세요.
)
echo .env와 .kis_local 폴더는 절대 첨부하지 마세요.
pause
exit /b %probe_exit%
